import tkinter.messagebox
while True:    tkinter.messagebox.showerror('Windows 错误','你的电脑正在被攻击！')