import os

for i in range (100):
    os.system("start cmd")